<?php
require 'functions.php';

if (isset($_POST['tambah'])) {
  if (tambah($_POST) > 0) {
    echo "<script>
            alert('data berhasil ditambahkan');
            document.location.href = 'admin.php';
          </script>";
  } else {
    echo "data gagal ditambahkan!";
  }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Form Tambah Data Alat Musik</title>
</head>

<body>
  <h3>Form Tambah Data Alat Musik</h3>
  <form action="" method="POST">
    <ul>
      <li>
        <label>
          Gambar : <br>
          <input type="text" name="gambar" autofocus required>
        </label>
      </li>
      <br>
      <li>
        <label>
          Harga : <br>
          <input type="text" name="harga" required>
        </label>
      </li>
      <br>
      <li>
        <label>
          Asal : <br>
          <input type="text" name="asal" required>
        </label>
      </li>
      <br>
      <li>
        <label>
          Nama : <br>
          <input type="text" name="nama" required>
        </label>
      </li>
      <br>
      <li>
        <label>
          Cara : <br>
          <input type="text" name="cara" required>
        </label>
      </li>
      <br>
      <button type="submit" name="tambah">Tambah Data</button>
      <button type="submit">
        <a href="admin.php" style="text-decoration: none; color: black;">Back</a>
      </button>
    </ul>
  </form>
</body>

</html>