<?php
require 'functions.php';

if (!isset($_GET['id'])) {
  header("Location: admin.php");
  exit;
}

$id = $_GET['id'];

$alat = query("SELECT * FROM alatmusik WHERE id = $id");

if (isset($_POST['ubah'])) {
  if (ubah($_POST) > 0) {
    echo "<script>
          alert('Data berhasil diubah');
          document.location.href = 'admin.php';
         </script>";
  } else {
    echo "Data gagal diubah!";
  }
}

?>
<!DOCTYPE html>
<head>
  <title>Ubah Data Alat Musik</title>
</head>

<body>
  <h3>Form Ubah Data Alat Musik</h3>
  <form action="" method="POST">
    <input type="hidden" name="id" value="<?= $alat['id']; ?>">
    <ul>
      <li>
        <label>
          Gambar : <br>
          <input type="text" name="foto" autofocus required value="<?= $alat['gambar']; ?>">
        </label>
      </li>
      <br>
      <li>
        <label>
          Harga : <br>
          <input type="text" name="nama_barang" required value="<?= $alat['harga']; ?>">
        </label>
      </li>
      <br>
      <li>
        <label>
          Asal : <br>
          <input type="text" name="brand" required value="<?= $alat['asal']; ?>">
        </label>
      </li>
      <br>
      <li>
        <label>
          Nama : <br>
          <input type="text" name="spesifikasi" required value="<?= $alat['nama']; ?>">
        </label>
      </li>
      <br>
      <li>
        <label>
          Cara : <br>
          <input type="text" name="keunggulan" required value="<?= $alat['cara']; ?>">
        </label>
      </li>
      <br>
      <button type="submit" name="ubah">Ubah Data</button>
      <button type="submit">
        <a href="admin.php" style="text-decoration: none; color: black;">Back</a>
      </button>
    </ul>
  </form>
</body>

</html>