<?php
if (!isset($_GET['id'])) {
	header("location: ../index.php");
	exit;
}

require 'functions.php';
$id = $_GET['id'];

$alatmusik = query("SELECT * FROM alatmusik WHERE id = $id");
?>

<!DOCTYPE html>
<head>
	<title>Detail</title>
</head>
<body>
	<div class="container">
		<div class="gambar">
			<img src="../assets/gambar/<?= $alatmusik["gambar"]; ?>" alt="">
		</div>
		<div class="ket">
			<p><?= $elektronik["harga"]; ?></p>
			<p><?= $elektronik["asal"]; ?></p>
			<p><?= $elektronik["nama"]; ?></p>
			<p><?= $elektronik["cara"]; ?></p>
		</div>
		<button class="tombol-kembali"><a href="../index.php">kembali</a></button>
	</div>
</body>

</html>