<?php
require 'php/functions.php';

$alatmusik = query("SELECT * FROM alatmusik");

if (isset($_POST['cari'])) {
	$alatmusik = cari($_POST['keyword']);
}
?>

<!DOCTYPE html>
<head>
	<title>Hapus Data Alat Musik</title>
</head>

<body>
	<div class="container">
		<h1>Hapus Data Alat Musik</h1>
		<div class="cari">
			<form action="" method="POST">
				<input type="text" name="keyword" size="56" placeholder="masukan keyword pencarian.." autocomplete="off" autofocus>
				<button type="submit" name="cari">Cari</button>
			</form>
		</div>
		<?php foreach ($alatmusik as $alat) : ?>
			<p class="nama">
				<a href="php/detail.php?id=<?= $alat['id'] ?>"><?= $alat["harga"] ?></a>
			</p>
		<?php endforeach; ?>
		<?php if (empty($alatmusik)) : ?>
			<tr>
				<td>
					<p style="font-size: 80px; color: blue; margin-bottom: 300px;text-align: center;">Data elektronik tidak ditemukan!</p>
				</td>
			</tr>
		<?php endif; ?>
		<button type="submit">
			<a href="php/admin.php" style="text-decoration: none; color: black;">Halaman Admin</a>
		</button>
	</div>
</body>

</html>