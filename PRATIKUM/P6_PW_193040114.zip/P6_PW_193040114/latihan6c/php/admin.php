<?php
require 'functions.php';

$alatmusik = query("SELECT * FROM alatmusik")

?>

  <!DOCTYPE html>
  <html lang="en">
  <head>
    <title>Hal Admin</title>
  </head>
  <body>
    <div class="container">
      <h1>Data Alat Musik</h1>
      <table border="1" cellspacing="0" cellpadding="17">
        <tr>
          <td>
            <h4>No</h4>
          </td>
          <td>
            <h4>Opsi</h4>
          </td>
          <td>
            <h4>Gambar</h4>
          </td>
          <td>
            <h4>Harga</h4>
          </td>
          <td>
            <h4>Asal</h4>
          </td>
          <td>
            <h4>Nama</h4>
          </td>
          <td>
            <h4>Cara</h4>
          </td>
        </tr>

        <?php $i = 1 ?>
        <?php foreach ($alatmusik as $alat) : ?>
          <tr>
            <td><?= $i ?></td>    
          <td>
            <a href="ubah.php?id=<?= $alat['id']; ?>"><button class="ubah">Ubah</button></a>
            <a href="hapus.php?id=<?= $alat['id']; ?>" onclick="return confirm('Apakah anda yakin?') "><button class="hapus">Hapus</button></a>
          </td>
            <td><img src="../assets/gambar/<?= $alat["gambar"]; ?>" ></td>
            <td><?= $alat["harga"] ?></td>
            <td><?= $alat["asal"] ?></td>
            <td><?= $alat["nama"] ?></td>
            <td><?= $alat["cara"] ?></td>
          </tr>
          <?php $i++ ?>
        <?php endforeach; ?>

      </table>
    </div>
  </body>

  </html>
