<?php
function koneksi() {
	$conn = mysqli_connect("localhost", "root", "") or die("koneksi ke DB gagal");
	mysqli_select_db($conn, "pw_193040114") or die("Database salah!!");

	return $conn;
}

function query($query) {
	$conn = koneksi();
	$result = mysqli_query($conn, $query);
	if (mysqli_num_rows($result) == 1) {
		return mysqli_fetch_assoc($result);
	}
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}
	return $rows;
}
function tambah($data) {
	$conn = koneksi();

	 		$harga = htmlspecialchars($data['harga']);
            $asal = htmlspecialchars($data['asal']);
            $nama = htmlspecialchars($data['nama']);
            $cara = htmlspecialchars($data['cara']);
            $gambar = htmlspecialchars($data['gambar']);

	 $query = "INSERT INTO alatmusik
                    VALUES 
                    ('', '$gambar', '$harga', '$asal', '$nama', '$cara')";
                    
	mysqli_query($conn, $query) or die(mysqli_error($conn));
	echo mysqli_error($conn);
	return mysqli_affected_rows($conn);
}
function hapus($id) {
	$conn = koneksi();
	mysqli_query($conn, "DELETE FROM alatmusik WHERE id = $id") or die(mysqli_error($conn));
	return mysqli_affected_rows($conn);
}
function ubah($data) {
	$conn = koneksi();

			$id = $data['id'];
			$harga = htmlspecialchars($data['harga']);
  		    $asal = htmlspecialchars($data['asal']);
            $nama = htmlspecialchars($data['nama']);
            $cara = htmlspecialchars($data['cara']);
            $gambar = htmlspecialchars($data['gambar']);

	$query = "UPDATE alatmusik SET

					  gambar = '$gambar',
                    harga = '$harga',
                    asal = '$asal',
                    nama = '$nama',
                    cara = '$cara',
                    WHERE id = '$id'
                    ";
					
	mysqli_query($conn, $query) or die(mysqli_error($conn));
	echo mysqli_error($conn);
	return mysqli_affected_rows($conn);
}

function cari($keyword) {
	$conn = koneksi();

	$query = "SELECT * FROM alatmusik
						WHERE 
						gambar LIKE '%$keyword%' OR 
						harga LIKE '%$keyword%' OR
						asal LIKE '%$keyword%' OR
						nama LIKE '%$keyword%' OR
						cara LIKE '%$keyword%' OR
					 ";
	$result = mysqli_query($conn, $query);

	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}


	return $rows;
}
?>